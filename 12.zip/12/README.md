# CS 174 Final Project: Cop Car
Khoi Nguyen, 804993073  
Kevin Yi, 504796248

## Description:
You play as a cop car, trying to arrest all the criminals roaming around the city! Arrest them all, and make sure not to hit any buildings on the way.

## Individual Contributions:
Kevin Yi: Cop Car, Game Logic, Ground/Streets  
Khoi Nguyen: Humans, Collision Detection, Texture Mapping

## Advanced Features Used:
Scene Graph/Hierarchical Object: Cop Car  
Collision Detection: Cop Car, Humans, Buildings  
Physics: Car Steering Physics